import EventEmitter from 'EventEmitter';

var AppEventEmitter = new EventEmitter();

export default AppEventEmitter;