var firebaseConfig = {
    "apiKey": "AIzaSyDsPufr5Dhusqal0bB8VDD9N6yv9u0Lo1E",
    "authDomain": "tester-8e38d.firebaseapp.com",
    "databaseURL": "https://tester-8e38d.firebaseio.com",
    "projectId": "tester-8e38d",
    "storageBucket": "tester-8e38d.appspot.com",
    "messagingSenderId": "490493205074",
    "appId": "1:490493205074:web:273a77dc5505447a"
}; 
exports.config = firebaseConfig;